'use client';

import { useState, useRef, useEffect, useCallback } from 'react';

/**
 * Protocollo WebSocket Gateway OpenClaw
 */

export interface ChatMessage {
  id?: number;
  ts: number;
  user_id?: string;
  role: 'user' | 'assistant' | 'agent' | 'system';
  content: string;
  model?: string;
  sessionKey?: string;
  openclaw_session_id?: string;
}

export interface ChatSessionInfo {
  sessionId: string;
  key: string;
  label: string;
  msgCount: number;
  preview: string;
  lastTs: number;
  source: string;
  model?: string;
  kind?: string;
}

type ConnectionStatus = 'disconnected' | 'connecting' | 'connected' | 'error';

interface WSPayload {
  type: string;
  sessionKey?: string;
  payload?: any;
  message?: string;
  agentId?: string;
  messages?: ChatMessage[];
}

interface UseChatGatewayWSReturn {
  status: ConnectionStatus;
  error: string | null;
  connected: boolean;
  
  // Funzioni core
  sendMessage: (sessionKey: string, message: string, agentId?: string) => Promise<string>;
  fetchHistory: (sessionKey: string) => Promise<ChatMessage[]>;
  abortRun: (sessionKey: string) => void;
  deleteSession: (sessionKey: string) => Promise<void>;
  
  // Event Handlers (settabili dal componente che usa l'hook)
  onDelta: ((data: { sessionKey: string; text: string }) => void) | null;
  onRunComplete: ((sessionKey: string) => void) | null;
  onToolProgress: ((data: { toolName: string; status: string }) => void) | null;
  onError: ((sessionKey: string, error: string) => void) | null;
  onSessionUpdate: ((sessions: ChatSessionInfo[]) => void) | null;
}

const RECONNECT_INTERVALS = [1000, 2000, 5000, 10000, 30000];
const CONNECTION_TIMEOUT = 10000;

export function useChatGatewayWS(): UseChatGatewayWSReturn {
  const [status, setStatus] = useState<ConnectionStatus>('disconnected');
  const [error, setError] = useState<string | null>(null);
  
  const ws = useRef<WebSocket | null>(null);
  const reconnectCount = useRef(0);
  const reconnectTimer = useRef<any>(null);
  const messageBuffer = useRef<string[]>([]);
  const pendingRequests = useRef<Map<string, { resolve: Function; reject: Function }>>(new Map());

  // Callbacks refs per evitare re-render loop se passati come props instabili
  const callbacks = useRef({
    onDelta: null as UseChatGatewayWSReturn['onDelta'],
    onRunComplete: null as UseChatGatewayWSReturn['onRunComplete'],
    onToolProgress: null as UseChatGatewayWSReturn['onToolProgress'],
    onError: null as UseChatGatewayWSReturn['onError'],
    onSessionUpdate: null as UseChatGatewayWSReturn['onSessionUpdate'],
  });

  const connect = useCallback(() => {
    if (ws.current?.readyState === WebSocket.OPEN) return;

    setStatus('connecting');
    setError(null);

    // In produzione userebbe wss://host:3720/ws, in locale ws://localhost:3740
    // Usa l'host corrente del browser per connettersi allo stesso dominio
    // Il proxy WS è esposto su 3740, ma il browser arriva su 3720
    // In produzione via Traefik, va su wss://stesso-dominio/ws
    // WS proxy integrato su /ws (stessa porta, stesso host)
    // Quando via HTTPS, usa wss://; quando via HTTP, ws://
    const loc = typeof window !== 'undefined' ? window.location : null;
    const protocol = loc?.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = loc?.host || 'localhost:3720';
    const wsUrl = (typeof window !== 'undefined' && (window as any).NEXT_PUBLIC_WS_URL) || `${protocol}//${host}/ws`;
    
    try {
      const socket = new WebSocket(wsUrl);
      ws.current = socket;

      const timeout = setTimeout(() => {
        if (socket.readyState !== WebSocket.OPEN) {
          socket.close();
          setStatus('error');
          setError('Connection timeout');
        }
      }, CONNECTION_TIMEOUT);

      socket.onopen = () => {
        clearTimeout(timeout);
        setStatus('connected');
        reconnectCount.current = 0;
        
        // Invia messaggi bufferizzati
        while (messageBuffer.current.length > 0) {
          const msg = messageBuffer.current.shift();
          if (msg) socket.send(msg);
        }
      };

      socket.onmessage = (event) => {
        try {
          const data: WSPayload = JSON.parse(event.data);
          handleMessage(data);
        } catch (e) {
          console.error('[WS] Parse error:', e);
        }
      };

      socket.onclose = () => {
        setStatus('disconnected');
        scheduleReconnect();
      };

      socket.onerror = (ev) => {
        console.error('[WS] Error:', ev);
        setStatus('error');
        setError('WebSocket connection error');
      };

    } catch (err) {
      console.error('[WS] Connection failed:', err);
      setStatus('error');
      setError('Failed to create WebSocket');
      scheduleReconnect();
    }
  }, []);

  const scheduleReconnect = useCallback(() => {
    if (reconnectTimer.current) return;
    
    const delay = RECONNECT_INTERVALS[Math.min(reconnectCount.current, RECONNECT_INTERVALS.length - 1)];
    reconnectCount.current++;
    
    reconnectTimer.current = setTimeout(() => {
      reconnectTimer.current = null;
      connect();
    }, delay);
  }, [connect]);

  const handleMessage = (data: WSPayload) => {
    switch (data.type) {
      case 'chat':
        if (data.payload?.text !== undefined) {
          callbacks.current.onDelta?.({
            sessionKey: data.sessionKey || '',
            text: data.payload.text
          });
        }
        if (data.payload?.toolName) {
          callbacks.current.onToolProgress?.({
            toolName: data.payload.toolName,
            status: data.payload.status || 'running'
          });
        }
        if (data.payload?.status === 'completed') {
          callbacks.current.onRunComplete?.(data.sessionKey || '');
        }
        break;

      case 'session.message':
        callbacks.current.onRunComplete?.(data.payload?.sessionKey || '');
        break;

      case 'chat.history':
        const reqKey = `history:${data.sessionKey}`;
        const pending = pendingRequests.current.get(reqKey);
        if (pending) {
          pending.resolve(data.payload?.messages || []);
          pendingRequests.current.delete(reqKey);
        }
        break;

      case 'sessions.changed':
        callbacks.current.onSessionUpdate?.(data.payload?.sessions || []);
        break;

      case 'error':
        callbacks.current.onError?.(data.sessionKey || 'global', data.payload?.message || 'Unknown error');
        break;
    }
  };

  const sendWithBuffer = (data: any) => {
    const json = JSON.stringify(data);
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send(json);
    } else {
      messageBuffer.current.push(json);
      if (status !== 'connecting') connect();
    }
  };

  const sendMessage = useCallback(async (sessionKey: string, message: string, agentId?: string): Promise<string> => {
    sendWithBuffer({
      type: 'chat.send',
      sessionKey,
      message,
      agentId
    });
    return sessionKey;
  }, [connect, status]);

  const fetchHistory = useCallback(async (sessionKey: string): Promise<ChatMessage[]> => {
    return new Promise((resolve, reject) => {
      const reqKey = `history:${sessionKey}`;
      pendingRequests.current.set(reqKey, { resolve, reject });
      
      sendWithBuffer({
        type: 'chat.history',
        sessionKey
      });

      // Timeout per la richiesta specifica
      setTimeout(() => {
        if (pendingRequests.current.has(reqKey)) {
          pendingRequests.current.delete(reqKey);
          reject(new Error('History request timeout'));
        }
      }, 5000);
    });
  }, [connect, status]);

  const abortRun = useCallback((sessionKey: string) => {
    sendWithBuffer({
      type: 'chat.abort',
      sessionKey
    });
  }, [connect, status]);

  const deleteSession = useCallback(async (sessionKey: string): Promise<void> => {
    sendWithBuffer({
      type: 'session.delete',
      sessionKey
    });
  }, [connect, status]);

  useEffect(() => {
    connect();
    return () => {
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      ws.current?.close();
    };
  }, [connect]);

  return {
    status,
    error,
    connected: status === 'connected',
    sendMessage,
    fetchHistory,
    abortRun,
    deleteSession,
    
    // Settabili esternamente
    get onDelta() { return callbacks.current.onDelta; },
    set onDelta(val) { callbacks.current.onDelta = val; },
    
    get onRunComplete() { return callbacks.current.onRunComplete; },
    set onRunComplete(val) { callbacks.current.onRunComplete = val; },
    
    get onToolProgress() { return callbacks.current.onToolProgress; },
    set onToolProgress(val) { callbacks.current.onToolProgress = val; },
    
    get onError() { return callbacks.current.onError; },
    set onError(val) { callbacks.current.onError = val; },
    
    get onSessionUpdate() { return callbacks.current.onSessionUpdate; },
    set onSessionUpdate(val) { callbacks.current.onSessionUpdate = val; },
  };
}
