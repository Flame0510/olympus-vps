// app/api/ws/route.ts
// WebSocket proxy route — Next.js App Router non supporta WS nativamente,
// ma questa route fa da ponte: il browser si connette a /api/ws,
// e il server Next.js gestisce l'upgrade e forwarda al proxy WS su 3740.
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

// Next.js 15+ non supporta upgrade WebSocket via Route Handler.
// Questa route esiste per documentare l'intento.
// Il WebSocket proxy è su ws://187.77.156.41:3740.

export async function GET(req: NextRequest) {
  return new NextResponse('WebSocket proxy disponibile su porta 3740. ' +
    'Per usarlo, connetti il browser a ws://HOST:3740',
    { status: 426, headers: { 'Content-Type': 'text/plain' } });
}
